
# CloudWalk Antifraud Challenge - Parte 3.2

## 📊 Análise Exploratória de Dados

**Total de transações:** 3199  
**Total de chargebacks:** 391  
**Proporção de chargebacks:** 12.22%  
**Máximo de transações por usuário:** 31  
**Máximo de chargebacks por usuário:** 25  
**Transações acima de R$1000:** 780

---

## 🕵️ Padrões suspeitos detectados

- Usuários com muitas transações consecutivas, alguns com até 25 chargebacks.
- Dispositivos sendo reutilizados em fraudes.
- Transações de alto valor acima de R$1000 com maior incidência de fraude.
- Maior concentração de fraudes no período noturno.

---

## 📈 Visualizações

Imagens geradas com base na amostra:
- `images/valor_transacoes.png`: Distribuição dos valores.
- `images/transacoes_por_hora.png`: Transações por hora com destaque para fraudes.

---

## 🔍 Dados adicionais sugeridos

1. IP e geolocalização
2. Sistema operacional/navegador
3. Tempo entre transações
4. Histórico de cartão e dispositivo
5. Nível de risco por comerciante

---

## 📁 Arquivos

- `images/`: Gráficos gerados
- `README.md`: Esta análise

---
